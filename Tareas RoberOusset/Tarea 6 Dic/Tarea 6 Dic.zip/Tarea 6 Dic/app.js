/*Objeto Persona
Crear un objeto llamado persona que contenga los siguientes atributos:
Nombre
Edad
DNI
Domicilio
Hijos (cantidad)
Profesión
Agregar Métodos:
Saludar ( mensaje de presentación en navegador o consola)
Listar (muestra la lista con los datos de la persona)
Arreglo de objetos
Crear un arreglo de objetos que contenga datos de películas como:
Título
Género
Año
sinopsis
Crea una función que permita mostrar en una lista cada película con sus datos.
*/

let persona = {
	nombre: "Roberto",
	apellido: "Ousset",
	edad: "35",
	DNI: "32413751",
	domicilio: "San Pablo",
	hjos: "3",
	profesion: "Ingeniero Industrial",
	saludar() {
		console.log(`Hola soy ${this.nombre} ${this.apellido}`);
	},
	listar() {
		for (const key in persona) {
			console.log(`${key}: ${persona[key]}`);
		}
	},
};

let arreglo = ["casa", "perro"];
let grupo = ["1", "2", "3"];

/* Prueba de listar un arreglo

const detalle = function () {
	arreglo.map(function (item, index) {
		console.log(`${index} ${item}`);
	});
};

// Prueba de una función para listar cualquier arreglo

const detalleGral = function (dato) {
	dato.map(function (listitem, index) {
		console.log(`${index} ${listitem}`);
	});
};
*/

let peliculas = [
	{
		titulo: "batman",
		genero: "accion",
		fecha: "2021",
		sinopsis: "excelente y recomendable",
	},
	{
		titulo: "rambo",
		genero: "accion",
		fecha: "2009",
		sinopsis: "muy buena pelicula",
	},
];

// Prueba 1 forma de listar
const listarPeliculas = function () {
	peliculas.map(function (peliculas, index) {
		console.log(
			`${index + 1} ==== titulo: ${peliculas.titulo}, genero: ${
				peliculas.genero
			}, fecha:${peliculas.fecha},sinopsis: ${peliculas.sinopsis}`
		);
	});
};

// Listar otra forma de listar

function detallePeli() {
	for (i = 0; i < peliculas.length; i++) {
		console.log("-------");
		for (const key in peliculas[i]) {
			console.log(`${key}: ${peliculas[i][key]}`);
		}
	}
}
